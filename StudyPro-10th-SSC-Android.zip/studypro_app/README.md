# StudyPro — Personal 10th SSC Study Companion

A mobile-first Android study planner built around the Class 10 SSC portion sheets provided for Model School, Dombivli East.

## Included
- Unit Test, I Term, Prelims, II Term and Board Exam sections
- Portion-based chapter checkboxes with progress percentages
- Subject-wise and exam-wise marks entry
- Overall percentage for each exam
- Marks improvement graph
- 60-minute study timer that switches to Break after completion
- Study minutes and completed-session tracking
- Daily timetable with Maths every day
- Subject-specific study tips
- Maths toolkit: calculator, percentage calculator and quadratic helper
- Android notifications, hourly motivation and one-off study reminders
- School exam web-search button (dates are not guessed when the provided portion sheets do not specify them)
- Dark blue UI inspired by the reference design
- All data stored locally on the phone with localStorage

## Build an APK on GitHub (phone-friendly)
1. Create a new GitHub repository.
2. Upload the contents of this folder.
3. Open **Actions** → **Build StudyPro APK** → **Run workflow**.
4. Wait for the workflow to finish.
5. Open the completed workflow run and download the **StudyPro-debug-apk** artifact.
6. Extract the artifact and install the APK on your Android phone.

The included GitHub Actions workflow installs Java, Android SDK and Gradle automatically, so you do not need Android Studio on your phone.

## Notes
The public web search did not reveal a reliable school-specific 2026 internal exam timetable. The school identity can be corroborated from public sources, but exact internal exam dates should be entered from the school's notice/teacher rather than guessed. The app therefore lets you enter an exam date and also includes a search button.
