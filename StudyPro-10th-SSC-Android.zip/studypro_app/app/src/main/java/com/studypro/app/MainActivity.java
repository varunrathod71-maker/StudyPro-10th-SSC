package com.studypro.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.*;
import android.widget.Toast;
import java.net.URLEncoder;
import java.util.*;

public class MainActivity extends Activity {
    WebView web;
    static final int REQ_NOTIF = 77;
    @Override public void onCreate(Bundle b){ super.onCreate(b);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(7,20,38));
        web = new WebView(this); web.setBackgroundColor(android.graphics.Color.rgb(7,20,38));
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient()); web.addJavascriptInterface(new Bridge(this), "Android");
        web.loadUrl("file:///android_asset/index.html"); setContentView(web);
        createChannels();
    }
    void createChannels(){ NotificationManager nm=getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("study","Study reminders",NotificationManager.IMPORTANCE_DEFAULT));
        nm.createNotificationChannel(new NotificationChannel("motivation","Motivation",NotificationManager.IMPORTANCE_DEFAULT));
    }
    void askNotif(){ if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIF); else Toast.makeText(this,"Notifications are enabled.",Toast.LENGTH_SHORT).show(); }
    void schedule(long delay, String title, String text, boolean hourly){
        Intent i=new Intent(this,StudyNotificationReceiver.class); i.putExtra("title",title); i.putExtra("text",text); i.putExtra("channel",hourly?"motivation":"study");
        int id=hourly?1001:(int)(System.currentTimeMillis()%100000);
        PendingIntent pi=PendingIntent.getBroadcast(this,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE); long when=System.currentTimeMillis()+delay;
        if(hourly) am.setInexactRepeating(AlarmManager.RTC_WAKEUP,when,60*60*1000L,pi); else am.set(AlarmManager.RTC_WAKEUP,when,pi);
    }
    void cancelHourly(){ Intent i=new Intent(this,StudyNotificationReceiver.class); PendingIntent pi=PendingIntent.getBroadcast(this,1001,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); ((AlarmManager)getSystemService(ALARM_SERVICE)).cancel(pi); }
    public class Bridge { Context c; Bridge(Context c){this.c=c;}
        @JavascriptInterface public void requestNotifications(){ runOnUiThread(()->askNotif()); }
        @JavascriptInterface public void enableHourlyMotivation(){ schedule(60*60*1000L,"StudyPro 💙","One focused hour can make tomorrow easier. Keep going!",true); runOnUiThread(()->Toast.makeText(MainActivity.this,"Hourly motivation enabled.",Toast.LENGTH_SHORT).show()); }
        @JavascriptInterface public void disableHourlyMotivation(){ cancelHourly(); }
        @JavascriptInterface public void scheduleReminder(int minutes,String title,String text){ schedule(Math.max(1,minutes)*60*1000L,title,text,false); }
        @JavascriptInterface public void openSearch(String q){ try{ String u="https://www.google.com/search?q="+URLEncoder.encode(q,"UTF-8"); startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))); }catch(Exception e){} }
    }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
