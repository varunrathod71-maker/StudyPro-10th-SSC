package com.studypro.app;
import android.app.*; import android.content.*; import android.os.Build;
public class StudyNotificationReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){
  String title=i.getStringExtra("title"); String text=i.getStringExtra("text"); String channel=i.getStringExtra("channel");
  if(title==null) title="StudyPro"; if(text==null) text="Time to check your study plan."; if(channel==null) channel="study";
  NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
  if(Build.VERSION.SDK_INT>=33 && c.checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=0) return;
  Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,channel):new Notification.Builder(c);
  b.setSmallIcon(com.studypro.app.R.drawable.ic_launcher).setContentTitle(title).setContentText(text).setAutoCancel(true);
  nm.notify((int)(System.currentTimeMillis()%100000),b.build());
 }
}
